import{l as o,a as r}from"../chunks/BEMLZ1wU.js";export{o as load_css,r as start};
