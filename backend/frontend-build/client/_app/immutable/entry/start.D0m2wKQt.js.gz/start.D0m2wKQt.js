import{l as o,a as r}from"../chunks/D7x77NIs.js";export{o as load_css,r as start};
