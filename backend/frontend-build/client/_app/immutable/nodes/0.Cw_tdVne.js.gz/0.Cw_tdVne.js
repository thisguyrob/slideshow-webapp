import"../chunks/CWj6FrbW.js";import{c as r,f as e,A as p,a as i}from"../chunks/D902iWF1.js";function c(n,o){var a=r(),t=e(a);p(t,()=>o.children),i(n,a)}export{c as component};
